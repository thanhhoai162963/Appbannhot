package com.example.appbanhangv2.view;

public class Sever {
    public static String localhost = "cuahangengineoil.000webhostapp.com";
    public static String DuongdanLoaisp = "http://"+localhost+ "/server/getloaisp.php";
    public static String DuongdanSanphamMoinhat  = "http://"+localhost+ "/server/getsanphammoinhat.php";
    public static String DuongdanNhotXeSo  = "http://"+localhost+ "/server/getsanpham.php?page=";
    public static String DuongdanDonhang  = "http://"+localhost+ "/server/thongtinkhachhang.php";

}
