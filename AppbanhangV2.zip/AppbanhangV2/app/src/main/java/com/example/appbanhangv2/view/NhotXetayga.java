package com.example.appbanhangv2.view;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.appbanhangv2.R;

public class NhotXetayga extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nhot_xetayga);
    }
}