package com.example.appbanhangv2.interfaces;

public interface OnListenUpdateTotal {
    void updateTotalProduct();
}
